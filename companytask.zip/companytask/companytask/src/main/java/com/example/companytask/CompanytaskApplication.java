package com.example.companytask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompanytaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompanytaskApplication.class, args);
	}

}
