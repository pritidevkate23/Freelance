package com.example.companytask.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.companytask.model.Item;


public interface ItemService {

	public Item addItem(Item item);
	 public Optional<Item> getItemById(Long id);
}
