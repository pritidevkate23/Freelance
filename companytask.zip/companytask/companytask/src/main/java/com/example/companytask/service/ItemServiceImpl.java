package com.example.companytask.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.companytask.model.Item;

@Service
public class ItemServiceImpl implements ItemService{
	
	private final List<Item> items=new ArrayList<>();
	private Long nextId=1L;

	@Override
	public Item addItem(Item item) {
		// TODO Auto-generated method stub
		item.setId(nextId++);
		items.add(item);
		return item;
	}

	@Override
	public Optional<Item> getItemById(Long id) {
		// TODO Auto-generated method stub
		
		
		return items.stream().filter(item->item.getId().equals(id)).findFirst();
	}

}
